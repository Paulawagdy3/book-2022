-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 29, 2021 at 09:17 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookmanagment`
--

-- --------------------------------------------------------

--
-- Table structure for table `Book`
--

CREATE TABLE `Book` (
  `id` int(11) NOT NULL,
  `AuthorName` varchar(30) NOT NULL,
  `img` varchar(30) NOT NULL,
  `BookTitle` varchar(30) NOT NULL,
  `Publisher` varchar(30) NOT NULL,
  `Keyword` varchar(30) NOT NULL,
  `Category` varchar(30) NOT NULL,
  `dis` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Book`
--

INSERT INTO `Book` (`id`, `AuthorName`, `img`, `BookTitle`, `Publisher`, `Keyword`, `Category`, `dis`) VALUES
(1, ' IZHAR RUSLAN ', 'img1.jpg', 'Kiamat', 'FIXI', 'IZHAR RUSLAN', '-', '-'),
(2, 'Muhammad Fatrim', 'img2.jpg', 'ASRAMA', 'FIXI', 'Muhammad Fatrim', '-', 'Dahlia, hati-hati dengan ASRAMA ni.” Maria tiba-tiba merendahkan suaranya sambil menatap roman Dahlia.\r\n\r\n“Kalau takat kau nak ingatkan aku pasal geng Queen yang macam syaitan tu, tak payah la.” Dahlia kurang senang dengan amaran Maria itu.'),
(3, 'Nadia Khan', 'img3.jpg', 'GANTUNG', 'FIXI', 'Nadia Khan', '-', 'Novel kedua oleh penulis novel bestseller KELABU.\r\n\r\n\"Musketeer Code - no all for one, just one for all.\"\r\nGibbs, Ray, KJ dan Troll – sekumpulan pelajar lelaki paling popular dan paling akrab di sebuah sekolah asrama elit. Mereka berempat mencipta Musketeer Code - peraturan yang tidak membenarkan sesiapa antara mereka mempunyai steady girlfriend, tetapi sebarang skandal amat dialu-alukan untuk dikongsi oleh semua.\r\n\r\nSehinggalah peraturan itu dilanggar... dan seorang awek psiko mencetuskan tragedi yang bakal menghantui hidup mereka semua.');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Name` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `PhoneNumber` varchar(13) NOT NULL,
  `UserName` varchar(8) NOT NULL,
  `Password` varchar(8) NOT NULL,
  `UserLevel` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Book`
--
ALTER TABLE `Book`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Book`
--
ALTER TABLE `Book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
